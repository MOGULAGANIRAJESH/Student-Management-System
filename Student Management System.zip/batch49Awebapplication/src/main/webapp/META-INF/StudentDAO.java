package com.vcube.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.utility.DBConnection;
import com.vcube.model.loginmodel;
import com.vcube.model.studentmodel;

import jakarta.servlet.RequestDispatcher;

public class StudentDAO {
	
	DBConnection db=new DBConnection();
	Connection con=db.getconnection();
	
	
	public studentmodel getStudent(int n)
	{ 
		
		studentmodel s = null;
		String selectdata="select * from student47 where sno=?";
		try
		{
			Connection con=db.getconnection();
		PreparedStatement ps=con.prepareStatement(selectdata);
		ps.setInt(1, n);
		ResultSet rs=ps.executeQuery();
		
		if(rs.next()) {
			s=new studentmodel(rs.getInt(1),rs.getString(2),rs.getString(3),
					rs.getString(4),rs.getInt(5),rs.getString(6),rs.getLong(7));
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return s;
		
	}
	
	public List<studentmodel> getall()
	{ 
		
		List<studentmodel> li=new ArrayList<studentmodel>();
		String selectdata="select * from student47";
		try
		{
			Connection con=db.getconnection();
		PreparedStatement ps=con.prepareStatement(selectdata);
		ResultSet rs=ps.executeQuery();
		
		while(rs.next()) {
			studentmodel s=new studentmodel(rs.getInt(1),rs.getString(2),rs.getString(3),
					rs.getString(4),rs.getInt(5),rs.getString(6),rs.getLong(7));
			li.add(s);
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return li;
		
	}
	public String insertstudentdata(studentmodel s)
	{
		String status="failure";
		String insertdata="insert into student47(firstname,lastname,username,password,email,phonenumber) values(?,?,?,?,?,?)";
		try
		{
		PreparedStatement ps=con.prepareStatement(insertdata);
		ps.setString(1, s.getFirstname());
		ps.setString(2, s.getLastname());
		ps.setString(3, s.getUsername());
		ps.setInt(4, s.getPassword());
		ps.setString(5, s.getEmail());
		ps.setLong(6, s.getPhonenumber());
		int n=ps.executeUpdate();
		if(n>0)
		{
			status="success";
		}
		else
		{
			status="failure";
		}
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return status;	
	}
	
	public String selectstudentdata(loginmodel l)
	{
		String status="failure";
		String selectdata="select *from student47 where firstname=?";
		try
		{
			Connection con=db.getconnection();
		PreparedStatement ps=con.prepareStatement(selectdata);
		ps.setString(1, l.getFirstname());
		ResultSet rs=ps.executeQuery();
		
		if(rs.next())
		{
			status="success";
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return status;
		
	}
	
	  public int updatestudentdata(studentmodel s) { 
		int n=0;
	  String updatedata="update student47 set firstname=?,lastname=?,username=?,password=?,email=?,phonenumber=? where sno=?";
	  try {
	  PreparedStatement ps=con.prepareStatement(updatedata); 
	  ps.setString(1, s.getFirstname());
	  ps.setString(2, s.getLastname());
	  ps.setString(3, s.getUsername());
	  ps.setInt(4, s.getPassword());
	  ps.setString(5, s.getEmail()); 
	  ps.setLong(6, s.getPhonenumber());
	  ps.setInt(7, s.getId());
	   n=ps.executeUpdate();
	  
	  
	  } catch(Exception e) { 
		  System.out.println(e); 
		  }
	  return n;
	  }
	  
	  
	  
	  public int deletestudentdata(studentmodel s)
	  
	  {
		  int n=0;
		  String deletedata="delete from student47 where sno=?";
		  try {
		  PreparedStatement ps=con.prepareStatement(deletedata); 
		  ps.setInt(1,s.getId());
		   n=ps.executeUpdate();
		  } 
		  catch(Exception e) 
		  { 
			  System.out.println(e); 
			  }
		  return n;
	  }	  
	  }
	  
	 	
	

